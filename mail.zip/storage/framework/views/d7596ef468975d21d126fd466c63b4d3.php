<!DOCTYPE html>
<html>

<head>
    <title>Job Application</title>
</head>

<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
        <?php echo $customBody; ?>

    </div>
</body>

</html><?php /**PATH D:\mail\resources\views/emails/job_application.blade.php ENDPATH**/ ?>